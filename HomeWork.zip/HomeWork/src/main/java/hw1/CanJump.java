package hw1;

public interface CanJump {
    void jump(int height);
}
