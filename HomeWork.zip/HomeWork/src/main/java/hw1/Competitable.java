package hw1;

public interface Competitable extends CanRun, CanJump{
}
