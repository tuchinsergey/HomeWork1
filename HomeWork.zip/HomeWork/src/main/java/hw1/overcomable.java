package hw1;

public interface overcomable{
    public void overcome (Competitable competitable);
}
