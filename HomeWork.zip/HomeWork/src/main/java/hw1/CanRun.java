package hw1;

public interface CanRun  {
    void run (int length);
}
